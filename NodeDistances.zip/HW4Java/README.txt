Input
The input file is given with the first line as the starting node and the remainder of the file is an adjacency list for graph GG (we assume that the set of vertices is {0,1,…,n−1}{0,1,…,n−1}). The adjacency list assumes that the current node is the index of the line under consideration. For instance line 0 of the input file (not including the starting node) has the list of all nodes adjacent to node 0.

For example

            	2		<- Starting node
	 	1 2		<- Node 0 shares edges with nodes 1 & 2
		0 3    		<- Node 1 shares edges with nodes 0 & 3
	    	0 3 4 5		<- Node 2 shares edges with nodes 0, 3, 4 & 5
		1 2 6 7		<- Node 3 shares edges with nodes 1, 2, 6 & 7
		2		<- Node 4 shares edges with node 2
		2		<- Node 5 shares an edge with node 2
		3 8		<- Node 6 shares an edge with nodes 3 & 8
		3 8		<- Node 7 shares edges with nodes 3 & 8
		6 7		<- Node 8 shares edges with nodes 6 & 7
		
Output
The output is every node (given by the index in the array), along with it's minimum distance from the starting node formatted as your language of choice's array-type data structure (see below for the exact details).
For example, using the example input from above:

           	[1, 2, 0, 1, 1, 1, 2, 2, 3]			<- Node 0 is distance 1 from node 2
								   Node 1 is distance 2 from node 2
								   Node 2 is distance 0 from itself 
								   Node 3 is distance 1 from node 2 
								   Node 4 is distance 1 from node 2
								   Node 5 is distance 1 from node 2
								   Node 6 is distance 2 from node 2
							 	   Node 7 is distance 2 from node 2
								   Node 8 is distance 3 from node 2

Compiling and executing from command line:

Assuming you're in the same directory level as Driver.java. Run javac Driver.java to compile.

To execute your code on input1.txt, run java Driver testcases/input1.txt. The output array will be printed to stdout.