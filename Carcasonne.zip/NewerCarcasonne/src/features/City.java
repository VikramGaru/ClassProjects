package features;

public class City extends Feature {

	public City(){
		
	}
	
	@Override
	public String type(){
		return "City";
	}
}
