package features;

public class Road extends Feature{
	
	public Road(){
		
	}
	@Override
	public String type(){
		return "Road";
	}

}
