package features;

public class Field extends Feature{

	public Field(){
		
	}
	@Override
	public String type(){
		return "Field";
	}
}
