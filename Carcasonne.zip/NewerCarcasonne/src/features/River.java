package features;

public class River extends Feature {

	public River(){
		
	}
	
	@Override
	public String type(){
		return "River";
	}
}

