We will consider matrix and vector multiplication, but with the caveat that we already know something about the matrix. In particular for any 0≤i,j≤n−10≤i,j≤n−1, we have
Un[i][j]={01if j<iotherwise.
Un[i][j]={0if j<i1otherwise.
If you "draw" this matrix you will note that all of the elements below the diagonal is zero: such matrices are called upper triangular matrices. Further, all non-zero values (in the "upper triangular" part) are all 11. Note that we only need to know the value of nn to completely determine UnUn.

You have to write code to solve the following computational problem: given any integer n≥1n≥1 and a vector xx of length nn, return the vector y=Un⋅xy=Un⋅x. Read on for more details on the format etc.

Sometimes it is easier to visualize a specific UnUn. Below is U5U5 written down in a 2D-array form:

                 1   1   1   1   1
                 0   1   1   1   1
                 0   0   1   1   1
                 0   0   0   1   1
                 0   0   0   0   1
                 
Input:
What you will receive is the vector itself. Each input file will contain one vector. The length of the vector will be on the first line of the file. The vector itself will take up the remaining lines. Once again, you will not have to handle the file reading and the creation of data structures. The packaged driver will handle that for you.

The input file can be summed up in the following format:

                n
                x0
                x1
                x2
                .
                .
                .
                xn-1
            