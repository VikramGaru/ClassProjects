Input
The input file is given as an adjacency list for graph GG (we assume that the set of vertices is {0,1,…,n−1}{0,1,…,n−1}). The adjacency list assumes that the current node is the index of the line under consideration. For instance line 0 of the input file has the list of all nodes adjacent to node 0.

                u1 u4 u6		<- All nodes that share edges with u0
            	u3 uu		<- All nodes that share edges with u1
		u0		<- All nodes that share edges with u2
		.
		.
		.
		u0 u4 u2 u7 	<- All nodes that share edges with un-1
	    
For example:

	 	1 2		<- Node 0 shares edges with nodes 1 & 2
		0 3    		<- Node 1 shares edges with nodes 0 & 3
	    	0 3 4 5		<- Node 2 shares edges with nodes 0, 3, 4 & 5
		1 2 6 7		<- Node 3 shares edges with nodes 1, 2, 6 & 7
		2		<- Node 4 shares edges with node 2
		2		<- Node 5 shares an edge with node 2
		3 8		<- Node 6 shares an edge with nodes 3 & 8
		3 8		<- Node 7 shares edges with nodes 3 & 8
		6 7		<- Node 8 shares edges with nodes 6 & 7
		
Output
The output is a list of nodes that will create a cycle. If our cycle is [u0, u1, ... um] where m is the legth of our cycle then we assume there exists an edge between every adjacent element in the list and that there is an edge between um and u0.

            	[u0 u1 u2... um]         <- u0 shares an edge with um & u1
                                           u1 shares an edge with u0 & u2
				           u2 shares an edge with u1 & u3
					   .
					   .
					   .
                                           um shares an edge with um-1 & u0
	    
For example, using the example input from above:

           	[0, 1, 3, 2]			<- Node 0 shares an edge with 1 & 3
						   Node 1 shares an edge with 0 & 3
						   Node 3 shares an edge with 1 & 2
						   Node 2 shares an edge with 3 & 0
						   

Compiling and executing from command line:

Assuming you're in the same directory level as Driver.java. Run javac Driver.java to compile.

To execute your code on input1.txt, run java Driver testcases/input1.txt. The output array will be printed to stdout.